package com.example.vitalage

data class MenuOption(
    val title: String,
    val icon: Int // ID del recurso drawable
)
